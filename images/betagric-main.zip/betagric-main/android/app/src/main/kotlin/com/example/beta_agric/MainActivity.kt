package com.example.beta_agric

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
